package com.gerenciadorTarefas.GerenciadorTarefas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.gerenciadorTarefas.GerenciadorTarefas.model.Tarefa;
import com.gerenciadorTarefas.GerenciadorTarefas.repository.CategoriaRepository;
import com.gerenciadorTarefas.GerenciadorTarefas.repository.TarefaRepository;
import com.gerenciadorTarefas.GerenciadorTarefas.repository.UsuarioRepository;

import java.time.LocalDate;

@Controller
@RequestMapping("/tarefas")
public class TarefaController {

    @Autowired
    private TarefaRepository tarefaRepository;

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/nova")
    public String novaTarefa(Model model) {
        model.addAttribute("tarefa", new Tarefa());
        model.addAttribute("categorias", categoriaRepository.findAll());
        model.addAttribute("usuarios", usuarioRepository.findAll());
        return "tarefa-form";
    }

    @PostMapping("/salvar")
    public String salvarTarefa(@ModelAttribute Tarefa tarefa) {
        tarefa.setDataCriacao(LocalDate.now());
        tarefaRepository.save(tarefa);
        return "redirect:/tarefas";
    }

    @GetMapping
    public String listarTarefas(Model model) {
        model.addAttribute("tarefas", tarefaRepository.findAll());
        return "lista-tarefas";
    }
}