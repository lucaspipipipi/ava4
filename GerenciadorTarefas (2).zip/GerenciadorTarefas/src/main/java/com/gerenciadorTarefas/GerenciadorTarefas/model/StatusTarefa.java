package com.gerenciadorTarefas.GerenciadorTarefas.model;

public enum StatusTarefa {
    ABERTA,
    ATRASADA,
    CONCLUIDA
}
